#include <iostream>
using namespace std;
#include <mutex>
#include <thread>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>

static std::mutex g_mutex;


class Singleton
{
 public:
    static Singleton *getInstance()
    {
        cout << "into getInstance" << endl;
        if(pInstance == NULL)
        {
            cout<< "into pInstance == NULL" << endl;
            g_mutex.lock();
            if(pInstance == NULL) //线程的切换
                pInstance = new Singleton;
                cout<< "getinstance" <<endl;
            g_mutex.unlock();
        }
 
        return pInstance;
    }
private:
    Singleton() { }
 
    static Singleton *pInstance;
};


Singleton *Singleton::pInstance = NULL;

static void* s_thread1(void* arg){
    
    Singleton* Instance = Singleton::getInstance();
    if(Instance)
    {
        cout << "thread1 getinstance success" << endl;
    }
}

static void* s_thread2(void* arg){
    Singleton* Instance = Singleton::getInstance();
    if(Instance)
    {
        cout << "thread2 getinstance success" << endl;
    }
}

int main()
{
    pthread_t thread1 = 0;
	pthread_t thread2 = 0;
	if(pthread_create(&thread1,NULL,s_thread1,NULL)!=0){
		cout<<"创建线程1失败"<< endl;
	}
    else
    {
        cout<<"创建线程1 success"<< endl;
    }

    if(pthread_create(&thread2,NULL,s_thread2,NULL)!=0){
		cout<<"创建线程2失败"<<endl;	
	}
    else
    {
        cout<<"创建线程2 success"<< endl;
    }


    return 0; 
}